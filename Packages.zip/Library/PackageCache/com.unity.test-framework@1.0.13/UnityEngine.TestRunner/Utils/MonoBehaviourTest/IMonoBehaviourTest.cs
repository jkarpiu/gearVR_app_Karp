namespace UnityEngine.TestTools
{
    public interface IMonoBehaviourTest
    {
        bool IsTestFinished {get; }
    }
}
